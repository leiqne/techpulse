﻿//ACTUALMENTE EN DESUSO

namespace API.Entities.Products.Interfaces;

public record ProviderId(int Id)
{
    public ProviderId() : this(0)
    {
    }
}