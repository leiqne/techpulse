﻿using API.Entities.Providers;

namespace API.Entities.Products.Interfaces;

public record ProductResource(string Name, int PId);