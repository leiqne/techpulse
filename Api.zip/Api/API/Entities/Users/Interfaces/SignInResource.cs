﻿namespace API.Entities.Users.Interfaces;

public record SignInResource(string UserName, string Password);