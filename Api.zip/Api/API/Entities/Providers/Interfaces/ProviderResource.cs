﻿namespace API.Entities.Providers.Interfaces;

public record ProviderResource(string Name, string Address, string Link);