﻿namespace API.Services.Tokens.Interfaces;

public class TokenSettings
{
    public string Secret { get; set; }
}